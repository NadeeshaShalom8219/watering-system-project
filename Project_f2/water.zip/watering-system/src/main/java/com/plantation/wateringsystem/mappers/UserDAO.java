package com.plantation.wateringsystem.mappers;

import com.plantation.wateringsystem.models.User;

public class UserDAO {

    public User getUserDetailsByUserID(int userId){
        if(userId == 001){
            return new User(001, "Nadeesha", "Shalom");
            //connect to sql database  using springboot hibernate
        }
        else return null;
    }
}
