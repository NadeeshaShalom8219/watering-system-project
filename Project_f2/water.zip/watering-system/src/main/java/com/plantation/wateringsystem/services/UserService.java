package com.plantation.wateringsystem.services;

import com.plantation.wateringsystem.mappers.UserDAO;
import com.plantation.wateringsystem.models.User;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    public User getUserDetails(int userId){
        UserDAO userdao = new UserDAO();
        User userDetails = userdao.getUserDetailsByUserID(userId);
        return userDetails;
    }

}
