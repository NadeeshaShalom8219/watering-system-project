package com.plantation.wateringsystem.controllers;

import com.plantation.wateringsystem.models.User;
import com.plantation.wateringsystem.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Objects;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;

    @GetMapping("/get-user-details")
    public ResponseEntity<User> getUserDetails(@RequestParam(name = "userId", required = true) int userId){
        User user = userService.getUserDetails(userId);
        if(!Objects.isNull(user)) {
            return new ResponseEntity<>(user, HttpStatus.ACCEPTED);
        }else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    //In android app
    //call webclient to get data in android
//    response.getStatus == HttpStatus.NOT_FOUND(
//       show error message we cant find a user with given detatils
//    )
}
